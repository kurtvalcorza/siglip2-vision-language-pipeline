"""Probes for the SVR review (siglip2-vision-language-pipeline) of DIMER_MultiModel_Vision_Language_Retrieval_Workshop.ipynb.

Usage: python run_probes.py <repo-root> [results.json]

CPU-only. Executes the notebook's own helper functions (retrieval_metrics, candidate_oracle,
rerank_with_blip, load_byod) with NumPy data and inert stand-ins; no model weights are loaded and
no GPU is used. Static probes read the notebook source. Hosted-evidence probes read the archived
2026-09-26 executed notebook (docs/execution-evidence). Each probe records `defect` (True = the
reviewed defect is present in the inspected source) and its evidence basis.

Probes P01-P14 are the blip-itm-pipeline BVR probes re-run against this repository's copy (identical
notebook blob e5651bb at the reviewed SHAs); SVR-<x> maps 1:1 to BVR-<x>. P15 (SVR-m10) and P16
(shared-unit identity) are specific to this repository.
"""
from __future__ import annotations

import ast
import hashlib
import io
import json
import re
import sys
import types
import zipfile
from pathlib import Path

import numpy as np

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("results.json")
NB = REPO / "tutorials" / "DIMER_MultiModel_Vision_Language_Retrieval_Workshop.ipynb"
EVIDENCE = REPO / "docs" / "execution-evidence" / "2026-09-26" / NB.name
cells = json.loads(NB.read_text(encoding="utf-8"))["cells"]
by_id = {c.get("id"): "".join(c["source"]) for c in cells}
md = "\n".join("".join(c["source"]) for c in cells if c["cell_type"] == "markdown")
results: list[dict] = []


def record(pid, finding, basis, defect, detail):
    results.append({"probe": pid, "finding": finding, "basis": basis, "defect": bool(defect), "detail": detail})


def helper_ns(tmp: Path, tier="STANDARD"):
    from PIL import Image

    ns = {"np": np, "Path": Path, "Image": Image, "json": json, "hashlib": hashlib, "RECALL_KS": (1, 5, 10),
          "WORK_ROOT": tmp / "work", "OUTPUT_ROOT": tmp / "out", "WORKSHOP_TIER": tier, "USE_BYOD": False,
          "RERANK_TOP_K": 5, "DEVICE": "cpu"}
    ns["OUTPUT_ROOT"].mkdir(parents=True, exist_ok=True)
    ns["sha256_file"] = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    for cid in ["2c66491b", "8477ecb0", "1705c558"]:
        mod = ast.parse(by_id[cid])
        mod.body = [n for n in mod.body if isinstance(n, ast.FunctionDef)]
        exec(compile(mod, cid, "exec"), ns)
    mod = ast.parse(by_id["05f2bcd3"])
    mod.body = [n for n in mod.body if isinstance(n, (ast.FunctionDef, ast.Import, ast.ImportFrom))]
    exec(compile(mod, "byod", "exec"), ns)
    return ns


def toy_grid(seed=0, n_images=30, caps=4):
    rng = np.random.default_rng(seed)
    owners = [i for i in range(n_images) for _ in range(caps)]
    scores = rng.normal(size=(n_images, len(owners)))
    for j, o in enumerate(owners):
        scores[o, j] += 1.2 + (0.0 if j % caps == 0 else 0.8)  # canonical caption weaker than the others
    texts = [f"caption {j}" for j in range(len(owners))]
    return scores, owners, texts


def p01_rerank_query_sets(tmp):
    ns = helper_ns(tmp)
    scores, owners, texts = toy_grid()
    index = {t: j for j, t in enumerate(texts)}
    # Order-preserving "reranker": ITM probability = sigmoid(coarse score). Reranked R@1 must equal coarse R@1
    # on the SAME queries; any gap in the notebook's row is a query-set artefact, not a reranking effect.
    fake = types.SimpleNamespace(itm_probabilities=lambda pairs: (
        [float(1 / (1 + np.exp(-scores[i, index[t]]))) for i, t in pairs], 0.0))
    res = ns["rerank_with_blip"](fake, list(range(scores.shape[0])), texts, owners, scores, 5)
    coarse_all = ns["retrieval_metrics"](scores, owners)["t2i_recall_at_1"]  # what cell e5928ea5 reports
    canon = ns["canonical_caption_indices"](owners, scores.shape[0])
    coarse_canon = float(np.mean([int(np.argmax(scores[:, j])) == owners[j] for j in canon]))
    row_keys = sorted(res)
    has_same_set_coarse = any("canonical" in k or "first_caption" in k for k in row_keys)
    record("P01", "SVR-M1", "direct execution (notebook helper, order-preserving stand-in reranker)",
           (not has_same_set_coarse) and abs(res["itm_t2i_recall_at_1"] - coarse_all) > 1e-9,
           {"coarse_t2i_r1_all_captions": coarse_all, "coarse_t2i_r1_canonical": coarse_canon,
            "itm_t2i_r1_noop_reranker": res["itm_t2i_recall_at_1"], "rerank_row_keys": row_keys,
            "note": "an order-preserving reranker should show delta 0; the notebook's coarse column differs"})


def p02_category_subgallery(tmp):
    src = by_id["58332fc5"]
    uses_subgallery = "np.ix_(image_indices,text_indices)" in src
    has_full_gallery = "full_gallery" in src
    # Identical score distribution, different category sizes: sub-gallery R@1 rises as the gallery shrinks.
    ns = helper_ns(tmp)
    rng = np.random.default_rng(1)
    n = 391
    owners = list(range(n))
    scores = rng.normal(size=(n, n)) + 2.0 * np.eye(n)
    small = list(range(160))
    big = list(range(160, n))
    r_small = ns["retrieval_metrics"](scores[np.ix_(small, small)], list(range(len(small))))["t2i_recall_at_1"]
    r_big = ns["retrieval_metrics"](scores[np.ix_(big, big)], list(range(len(big))))["t2i_recall_at_1"]
    record("P02", "SVR-M2", "direct execution (synthetic, same-quality scores) + source inspection",
           uses_subgallery and not has_full_gallery,
           {"subgallery_t2i_r1_160": r_small, "subgallery_t2i_r1_231": r_big,
            "hosted_categories": {"no-text": 160, "text": 231}, "uses_subgallery": uses_subgallery,
            "full_gallery_columns_present": has_full_gallery})


def p03_byod_result_display():
    src = by_id["05f2bcd3"]
    branch = src[src.index("if USE_BYOD:"):]
    shows = "display(" in branch
    md_cell = by_id["07a272b2"]
    upload_help = any(w in md_cell for w in ("Files pane", "Files panel", "upload"))
    record("P03", "SVR-M3", "source inspection", not shows or not upload_help,
           {"byod_branch_displays_tables": shows, "byod_markdown_explains_how_to_supply_zip": upload_help,
            "empty_path_message": re.findall(r"raise ValueError\('Set BYOD_ZIP_PATH[^']*'\)", src)})


def _archive(tmp, change):
    from PIL import Image

    rows, images = [], {}
    for i in range(2):
        s = io.BytesIO()
        Image.new("RGB", (32, 32), (i * 40, 1, 2)).save(s, format="PNG")
        images[f"images/{i}.png"] = s.getvalue()
        rows.append({"id": f"img{i}", "file": f"images/{i}.png", "captions": [f"photo {i}"], "split": "test"})
    change(rows, images)
    path = tmp / f"a{len(list(tmp.glob('a*.zip')))}.zip"
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("records.jsonl", "\n".join(json.dumps(r) for r in rows))
        for k, v in images.items():
            z.writestr(k, v)
    return path


def p04_byod_messages(tmp):
    cases = {
        "caption_count": (lambda r, i: r[1].update(captions=["a", "b", "c", "d", "e", "f"]), "img1"),
        "unknown_role": (lambda r, i: r[1].update(split="holdout"), "holdout"),
        "non_string_caption": (lambda r, i: r[1].update(captions=[7]), "img1"),
        "missing_file": (lambda r, i: r[1].update(file="images/nope.png"), "images/nope.png"),
        "duplicate_id": (lambda r, i: r[1].update(id="img0"), "img0"),
        "undeclared_image": (lambda r, i: i.update({"images/extra.png": i["images/0.png"]}), "extra.png"),
    }
    out = {}
    for name, (change, needle) in cases.items():
        ns = helper_ns(tmp)
        try:
            ns["load_byod"](_archive(tmp, change))
            out[name] = {"raised": False}
        except ValueError as exc:
            out[name] = {"raised": True, "message": str(exc), "names_offender": needle in str(exc)}
    typos = [t for t in ("outside16", "At most100") if t in by_id["05f2bcd3"]]
    record("P04", "SVR-m1", "direct execution (notebook load_byod on crafted archives)",
           any(not v.get("names_offender", False) for v in out.values()) or bool(typos),
           {"cases": out, "message_typos": typos})


def p05_caption_perturbation():
    heading = by_id["73e42590"].splitlines()[0]
    code = by_id["797b6acd"]
    implemented = "perturb" in code.lower() or "caption_perturbation" in code
    record("P05", "SVR-m3", "source inspection (notebook + docs/vision-language-retrieval-workshop-spec.md §68)",
           "perturbation" in heading.lower() and not implemented,
           {"heading": heading, "perturbation_code_present": implemented,
            "spec_requires": "§68 validation-only original/lowercase/shortened; output validation/caption_perturbation.csv"})


def p06_dat9_dat6():
    overlap = bool(re.search(r"pretrain|pre-train|overlap", md, re.I))
    licence = "CC BY" in md
    record("P06", "SVR-m2", "source inspection", not overlap or not licence,
           {"pretraining_overlap_statement": overlap, "corpus_licence_stated": licence})


def p07_pair_accuracy_explained():
    explained = bool(re.search(r"pair accuracy", md, re.I))
    record("P07", "SVR-m4", "source inspection", not explained,
           {"markdown_mentions_itm_pair_accuracy": explained,
            "columns_in_rerank_table": ["itm_pair_accuracy", "pair_evaluations", "seconds"]})


def p08_exercise_answers():
    ex = by_id["3b012ccb"]
    record("P08", "SVR-m5", "source inspection", "<details>" not in ex or "yourselfs" in ex,
           {"heading": ex.splitlines()[0], "sample_answers": ex.count("<details>")})


def p09_gallery_size_guidance():
    md_cell = by_id["5333fe70"]
    ev = {}
    if EVIDENCE.is_file():
        enb = json.loads(EVIDENCE.read_text(encoding="utf-8"))
        for c in enb["cells"]:
            if c.get("id") == "6ae280da":
                ev["saved_table"] = "".join(c["outputs"][0]["data"]["text/plain"])
    record("P09", "SVR-m6", "source inspection + documented execution evidence (2026-09-26, STANDARD)",
           len(md_cell.strip().splitlines()) <= 1,
           {"markdown": md_cell, "hosted": ev,
            "observation": "at 70 images SigLIP v1 i2t R@1 0.943 > SigLIP 2 0.900; at 391 SigLIP 2 0.790 > v1 0.783"})


def p10_bundle_scope():
    src = by_id["005e710a"]
    whole_dir = "make_archive" in src and "root_dir=Path(OUTPUT_DIR)" in src
    record("P10", "SVR-m7", "source inspection", whole_dir and "SESSION_STARTED" not in src,
           {"archives_entire_output_dir": whole_dir,
            "consequence": "files from an earlier tier/BYOD run in the same runtime are bundled with this run's manifest"})


def p11_completion_summary():
    src = by_id["76b36372"]
    has_results = "recall" in src.lower() or "rerank_table" in src
    record("P11", "SVR-m8", "source inspection", not has_results,
           {"summary_keys_mention_results": has_results})


def p12_objectives_full_only():
    obj = by_id["e4c7f831"]
    record("P12", "SVR-m9", "source inspection", "FULL" not in obj,
           {"objectives_11_12_marked_full": "FULL" in obj})


def p13_hosted_rerank_numbers():
    if not EVIDENCE.is_file():
        record("P13", "SVR-M1", "documented execution evidence", False, {"evidence": "missing"})
        return
    enb = json.loads(EVIDENCE.read_text(encoding="utf-8"))
    table = ""
    for c in enb["cells"]:
        if c.get("id") == "e5928ea5":
            table = "".join(c["outputs"][0]["data"]["text/plain"])
    record("P13", "SVR-M1", "documented execution evidence (2026-09-26 Colab T4 STANDARD)", True,
           {"saved_rerank_table": table,
            "note": "coarse_t2i_r1 is over 1,737 caption queries; itm_t2i_recall_at_1 over 391 first-caption queries"})


def p14_positive_controls(tmp):
    ns = helper_ns(tmp)
    m = ns["retrieval_metrics"](np.eye(4), [0, 1, 2, 3])
    ok = m["i2t_recall_at_1"] == 1.0 and m["t2i_recall_at_1"] == 1.0 and m["rsum"] == 6.0
    oracle = ns["candidate_oracle"](np.eye(4), [0, 1, 2, 3], 1)
    record("P14", "control", "direct execution", not ok,
           {"identity_metrics": m, "oracle_at_1": oracle})


def p15_registry():
    reg = (REPO / "tutorials" / "README.md").read_text(encoding="utf-8")
    rows = [ln for ln in reg.splitlines() if ln.startswith("| `")]
    has_row = any(NB.name in ln for ln in rows)
    colab = f"blob/main/tutorials/{NB.name}" in reg
    readme = (REPO / "README.md").read_text(encoding="utf-8")
    card = (REPO / "MODEL_CARD.md").read_text(encoding="utf-8")
    record("P15", "SVR-m10", "source inspection (tutorials/README.md, README.md, MODEL_CARD.md)",
           not has_row or not colab,
           {"registry_table_rows": [ln.split("|")[1].strip() for ln in rows], "workshop_row_present": has_row,
            "workshop_colab_link_present": colab, "readme_mentions_workshop": NB.name in readme,
            "model_card_mentions_workshop": NB.name in card,
            "registry_spec_line": next((ln for ln in reg.splitlines() if ln.startswith("Notebook specification")), ""),
            "notebook_declares_spec": json.loads(NB.read_text(encoding="utf-8"))["metadata"]["dimer"]["notebook_spec"]})


def p16_shared_unit_identity():
    import subprocess
    sib = REPO.parents[1] / "blip-itm-pipeline" if REPO.parent.name == "_wt" else REPO.parent / "blip-itm-pipeline"
    rel = "tutorials/" + NB.name
    own = subprocess.run(["git", "-C", str(REPO), "hash-object", str(NB)], capture_output=True, text=True).stdout.strip()
    detail = {"this_repo_blob": own}
    for ref in ("a25fdf6", "origin/main", "origin/fix/bvr-workshop-review"):
        r = subprocess.run(["git", "-C", str(sib), "rev-parse", f"{ref}:{rel}"], capture_output=True, text=True)
        detail[f"blip-itm-pipeline {ref}"] = r.stdout.strip() or r.stderr.strip()[:120]
    record("P16", "shared unit", "source inspection (git blob ids)", False, detail)


def main():
    import tempfile

    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d)
        p01_rerank_query_sets(tmp)
        p02_category_subgallery(tmp)
        p03_byod_result_display()
        p04_byod_messages(tmp)
        p05_caption_perturbation()
        p06_dat9_dat6()
        p07_pair_accuracy_explained()
        p08_exercise_answers()
        p09_gallery_size_guidance()
        p10_bundle_scope()
        p11_completion_summary()
        p12_objectives_full_only()
        p13_hosted_rerank_numbers()
        p14_positive_controls(tmp)
        p15_registry()
        p16_shared_unit_identity()
    payload = {"notebook": str(NB.relative_to(REPO)), "notebook_sha256": hashlib.sha256(NB.read_bytes()).hexdigest(),
               "environment": "CPU only; NumPy helpers + inert stand-ins; no model weights", "probes": results}
    OUT.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    for r in results:
        print(r["probe"], r["finding"], "DEFECT" if r["defect"] else "ok")


if __name__ == "__main__":
    main()
